package ovh.meimei;

import java.math.BigInteger;

public class Main {

    public static void main(String[] args) {
        Gencle.genKeys("keys", 512);
    }
}
