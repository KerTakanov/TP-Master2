package messages;

public class Ready {
}
