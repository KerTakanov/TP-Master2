package messages;

public class Synchronize {
}
