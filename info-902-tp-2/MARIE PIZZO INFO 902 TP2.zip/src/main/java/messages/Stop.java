package messages;

public class Stop {
}
