package messages;

/**
 * Diffuse un message indiquant que le Process actuel a perdu le lancé de dé
 */
public class Lost {
}
