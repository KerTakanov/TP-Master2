package messages;

public class HeartbitMessage extends Message {
    public HeartbitMessage(Integer sender) {
        super(null, null, null, sender);
    }
}
