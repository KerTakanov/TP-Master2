package messages;

public class Token {
}
