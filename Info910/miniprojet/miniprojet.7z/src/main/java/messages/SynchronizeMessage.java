package messages;

public class SynchronizeMessage extends Message {
    public SynchronizeMessage() {
        super(null, null, null, null);
    }
}
