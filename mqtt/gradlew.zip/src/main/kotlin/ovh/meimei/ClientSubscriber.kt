package ovh.meimei

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.MqttCallback
import org.eclipse.paho.client.mqttv3.MqttClient
import org.eclipse.paho.client.mqttv3.MqttMessage

class ConsumerCallback: MqttCallback {
    override fun messageArrived(topic: String?, message: MqttMessage?) {
        print("Message arrivé: $message")
    }

    override fun connectionLost(cause: Throwable?) {}

    override fun deliveryComplete(token: IMqttDeliveryToken?) {}

}

fun main(args: Array<String>) {
    val subscriber = MqttClient("tcp://localhost:1883", MqttClient.generateClientId())
    subscriber.setCallback(ConsumerCallback())
    subscriber.connect()
    subscriber.subscribe("iot_data")
}